CREATE TABLE Artists (
    artist_id number NOT NULL  PRIMARY KEY,
    name VARCHAR2(100) NOT NULL,
    surename	VARCHAR2(100) NOT NULL,
    Birthday	DATE,
    genre VARCHAR(50),
    formed_year INT
);

CREATE TABLE Albums (
    album_id number  PRIMARY KEY,
    title VARCHAR2(100) NOT NULL,
    release_year number,
    artist_id number,
    T_streams	NUMBER,
    FOREIGN KEY (artist_id) REFERENCES Artists(artist_id)
);

CREATE TABLE Songs (
    song_id INT  PRIMARY KEY,
    streams	NUMBER,
    title VARCHAR(100) NOT NULL,
    album_id INT,
    FOREIGN KEY (album_id) REFERENCES Albums(album_id)
);
