/*Find total streams*/

UPDATE Albums a
SET a.T_streams = (
    SELECT SUM(s.streams)
    FROM Songs s
    WHERE s.album_id = a.album_id
);

/*find top 100 albums with the most streams*/

SELECT a.title, a.release_year, a.T_streams AS total_streams
FROM Albums a
JOIN Songs s ON a.album_id = s.album_id
GROUP BY a.title, a.release_year, a.T_streams
ORDER BY total_streams DESC
FETCH FIRST 100 ROWS ONLY;

